<?php  
include('../Config/Constants.php');

  if(isset($_GET['id']) AND isset($_GET['img_name'])){ 



     $id=$_GET['id'];
     $img_name=$_GET['img_name'];
     //remoce the image file is available
     //delete from data set
     if($img_name !=""){ 
        //img is available
        $path="../Images/Product/".$img_name;
        //Remove the image
        $remove=unlink($path); //boolean variable true or false
        if($remove==false){ 
            $_SESSION['remove']="<div class='error'> Failed to remove product image</div>";
            header('location:'.SITEURL.'Admin/manageProduct.php');
            //stop the process
            die();
        }

     }
     //delete the data from database
     $sql="DELETE FROM tbl_product WHERE id=$id";
     $res=mysqli_query($conn,$sql);
     if($res==true){ 
        $_SESSION['delete']="<div class='sucess'>Product Deleted sucessfully</div>";
        header('location:'.SITEURL.'Admin/manageProduct.php');

     }
     else{ 
        $_SESSION['delete']="<div class='error'>failed to delete catagory</div>";
        header('location:'.SITEURL.'Admin/manageProduct.php');
     }




  }
  else{ 


  }

  

?>