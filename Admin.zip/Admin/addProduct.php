<?php include('Partials/menu.php'); ?>
<div class="main-content">
    <div class="wrapper">
        <h1>Add Product</h1>

        <?php
        if(isset($_SESSION['add_product'])){ 
            echo $_SESSION['add_product'];
            unset($_SESSION['add_product']);
        }
        if(isset($_SESSION['upload'])){ 
            echo $_SESSION['upload'];
            unset($_SESSION['upload']);
        }
        
        ?>
        <div class="tbl-full">
            <form action="" method="POST" enctype="multipart/form-data"> <!----------it is allow to us to upload file or imag------>
                <table>
                    <tr>
                        <td>Title:</td>
                        <td> <input type="text" name="title" placeholder="Product Title"></td>
                    </tr>
                    <tr>
                        <td>Select Image:</td>
                        <td> <input type="file" name="img"></td> 
                    </tr>
                    <tr> 
                        <td>Feature:</td>
                        
                        <td> <input type="radio" name="feature" value="Yes">  Yes</td>
                        <td> <input type="radio" name="feature" value="No">No</td>
                    </tr>
                    <tr>
                        <td> Active:</td>
                        <td>  <input type="radio" name="active" value="Yes">Yes</td>
                        <td>  <input type="radio" name="active" value="No">No</td>
                    </tr>
                    <tr>
                        <td colspan="2"> <input type="submit" name="submit" value="Add Product"></td>
                    </tr>
                </table>
            </form>
        </div>

    </div>
</div>
<?php include('Partials/footer.php'); ?>
<?php  

if(isset($_POST['submit'])){ 
    $title=$_POST['title'];
    if(isset($_POST['feature'])){ 
        $feature=$_POST['feature'];
    }
    else{ 
        $feature="No";
    }
    if(isset($_POST['active'])){ 
        $active=$_POST['active'];
    }
    else{ 
        $active="No";
    }
    //wheather img is selected or not
                        //print_r($_FILES['img']);
                         //die();   //break the code here
                         //if(isset($_FILES['img']['name']));
                         if(isset($_FILES['img']['name'])){ 
                            //upload the img
                            $img_name=$_FILES['img']['name'];
                           //renaming the img   specialfood1.jpg
                           $ext=end(explode('.',$img_name)); //get extension only extention only
                           $img_name="product_".rand(000,999).'.'.$ext;
                           
                          

                            $source_path=$_FILES['img']['tmp_name'];
                            
                            $destination_path="../images/Product/".$img_name;
                            $upload=move_uploaded_file($source_path,$destination_path);
                            //check wheater the img is uplloaded or not
                            if($upload==false){ 
                                $_SESSION['upload']="<div class='error'>Failed to upload image</div>";
                                header('location:'.SITEURL.'Admin/addProduct.php');
                                die();
                            }
                        
                         }
                         else{ 
                            //dont't upload img set the img value as blank
                            $img_name="";
                         }

    //create sql query to insert catagory into database
    $sql="INSERT INTO tbl_product SET
    title='$title',
    img_name='$img_name',
    feature='$feature',
    active='$active'
    ";
    $res=mysqli_query($conn,$sql);
    if($res==true){ 
        $_SESSION['add_product']="<div class='sucess'>Product Added successfully</div>";
        header('location:'.SITEURL.'Admin/manageProduct.php');
    }
    else{ 
        $_SESSION['add_product']="<div class='error'>failed to add product</div>";
        header('location:'.SITEURL.'Admin/addProduct.php');
    }

}
?>