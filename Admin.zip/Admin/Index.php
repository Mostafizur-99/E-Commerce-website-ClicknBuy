
<?php include('Partials/menu.php'); ?>
    <!--------menu end---------->
    <!-------main-content start--------->
    <div class="main-content">
        <div class="wrapper">
          <h1>Dashboard</h1>
         <?php 
         if(isset($_SESSION['login'])){ 
            echo $_SESSION['login'];
            unset($_SESSION['login']);
         } ?>

         <div class="main-sub">
          <div class="col-4">
           
         <h1>5</h1> <br> <h3>Catagory</h3>

          </div>
          <div class="col-4">
          <h1>5</h1> <br>  <h3>Catagory</h3>
</div>
<div class="col-4">
<h1>5</h1> <br> <h3>Catagory</h3>
</div>
<div class="col-4">
<h1>5</h1> <br> <h3>Catagory</h3>
</div>
</div>


        </div>
    </div>
    <!----------main content end---->
    <!-------------footer start------>
    <div class="footer">
        <div class="wrapper">
            <p class="text-center">all right resereved by <a href="">ClicknBuy</a></p>

        </div>
    </div>

<!------------footer end------------->
</body>
</html>