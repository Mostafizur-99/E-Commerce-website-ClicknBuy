<?php include('Partials/menu.php'); ?>
<div class="main-content">
    <div class="wrapper">
        <h1>Update Product</h1>
        <?php 

        if(isset($_GET['id'])){ 
            //get the id 
           // echo "do something";
            $id=$_GET['id'];
            $sql="SELECT *FROM tbl_product WHERE id=$id";
            $res=mysqli_query($conn,$sql);
            $count=mysqli_num_rows($res);
            if($count==1){ 

                //get all the data
                $row=mysqli_fetch_assoc($res);
                $title=$row['title'];
                $current_img=$row['img_name'];
                $feature=$row['feature'];
                $active=$row['active'];

            }
            else{ 
                //redirect sesion message
                $_SESSION['no-product-found']="<div class='error'>No product found</div>";
                header('location:'.SITEURL.'Admin/manageProduct.php');
            }

        }
        else{ 
           // echo "nothing";
           
           header('location:'.SITEURL.'Admin/manageProduct.php');
        }
           
      
          
        ?>
        <div class="tbl-full">
            <form action="" method="POST" enctype="mulipart/form-data">
                <table>
                    <tr>
                        <td>Title:</td>
                        <td>
                            <input type="text" name="title" value="<?php echo $title;?>">
                        </td>
                       
                    </tr>
                    <tr>
                        <td>
                             Image:
                        </td>
                        <td>
                         <img src="<?php echo SITEURL; ?>Images/Product/<?php echo $current_img;?>" alt="" height="70px" width="70px">
                        </td>
                    </tr>
                    <!--<tr>
                        <td>New image:</td>
                        <td> <input type="file" name="img" >  </td>
                    </tr>
                    --->
                    <tr>
                        <td>Feature:</td>
                        <td> 
                            <input 
                            <?php if($feature=="Yes") { echo "checked";} ?> type="radio" name="feature" value="Yes">YES
                            <input 
                            <?php if($feature=="No") { echo "checked";} ?> type="radio" name="feature" value="No">No
                    </td>
               
                    </tr>
                    <tr>
                        <td>
                            Active:
                        </td>
                        <td>
                        <input
                        <?php if($active=="Yes"){ echo "Checked";} ?> type="radio" name="active" value="Yes">YES
                        <input 
                        <?php if($active=="No"){echo "Checked"; } ?>
                        type="radio" name="active" value="No">No
                        </td>
                    </tr>
                    <tr>
                     <td>
                        <input type="hidden" name="current_img" value="<?php echo $current_img; ?>">
                        <input type="hidden" name="id" value="<?php echo $id; ?>">
                        <input type="submit" name="submit" value="update Product">
                     </td>   
                    </tr>

                </table>
            </form>
        </div>
        <?php
        if(isset($_POST['submit']))
        { 
           // echo "clicked";
           //1get all the value
           //update the value
           $title=$_POST['title'];
           $id=$_POST['id'];
           $current_img=$_POST['current_img'];
           $feature=$_POST['feature'];
           $active=$_POST['active'];
          //img updated
         /*  if(isset($_FILES['img']['name'])){ 
            $img_name=$_FILES['img']['name'];
              
            //sec A upload the new image 
            $ext=end(explode('.',$img_name)); //get extension only extention only
            $img_name="product_".rand(000,999).'.'.$ext;
            
            if($img_name!=" "){ 

             $source_path=$_FILES['img']['tmp_name'];
             
             $destination_path="../images/Product/".$img_name;
             $upload=move_uploaded_file($source_path,$destination_path);
             //check wheater the img is uplloaded or not
             if($upload==false){ 
                 $_SESSION['upload']="<div class='error'>Failed to upload image</div>";
                 header('location:'.SITEURL.'Admin/manageProduct.php');
                 die();
             }
            //remove the img
            $remove_path="../Images/Product/".$current_img;
            $remove=unlink($remove_path);
    
    //check wheather img is remove or not  if failed to remove
    if($remove==false){ 
        $_SESSION['failed-remove']="<div class='error'>failed to remove current img</div>";
        header('location:'.SITEURL.'Admin/manageProduct.php');
        die();
        
    }
    else{ 
       // $_SESSION['upload']="<div class='sucess'>Failed to upload image</div>";
        //header('location:'.SITEURL.'Admin/manageProduct.php');
        //die();

    }


           }
        }
    
    
          //remove the current img
            
           
           
           
           
           */
           
           $sql2="UPDATE tbl_product SET
             title='$title',
            
             feature='$feature',
             active='$active'
             WHERE id=$id
           ";
            //execute
          $res2=mysqli_query($conn,$sql2);

          if($res2==true){ 
           //Catagory updated
           $_SESSION['update']="<div class='sucess'>Product updated sucessfully</div>";
           header('location:'.SITEURL.'Admin/manageProduct.php'); 
      
          }
          else{ 
            //failed to updated catagory 
            $_SESSION['update']="<div class='error'>failed to update product</div>";
            header('location:'.SITEURL.'Admin/manageProduct.php'); 
          }



         }
        
         ?>
    </div>
</div>
<?php include('Partials/footer.php')?>


