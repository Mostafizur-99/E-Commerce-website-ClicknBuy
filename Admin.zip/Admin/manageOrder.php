<?php include('Partials/menu.php'); ?>
<div class="main-content">
    <div class="wrapper">
        <h1>Manage Order</h1>
        <div class="tbl-full">
            <table>
                <tr>
                    <th>SN</th>
                    <th>Name</th>
                    <th>Product Image</th>
                    <th>title</th>
                    <th>Quantity</th>
                    <th>total</th>
                    <th>payment method</th>
                    <th>Delivered</th>
                    
                </tr>
            </table>
        </div>
    </div>
</div>
<?php include('Partials/footer.php'); ?>