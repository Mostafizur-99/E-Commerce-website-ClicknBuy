
<?php include('../Config/Constants.php');
include('LoginCheck.php'); ?>
<html>
    <head>
        <title>Admin-ClicknBuy </title>
        <link rel="stylesheet" href="../CSS/admin.css">
        <script src="https://kit.fontawesome.com/6a32e98c79.js" crossorigin="anonymous"></script>
</head>
<body>
    <h1>Admin pannel</h1>

    <!--------------menu start------------>
    <div class="menu text-center">
        <div class="wrapper">
            <ul>
                <li><a href="./Index.php">Home</a></li>
                <li> <a href="./manageAdmin.php">Admin</a></li>
                <li> <a href="./manageProduct.php">product</a></li>
                <li> <a href="">order</a></li>
                <li> <a href=""><i class="fa-solid fa-user"></i> 
                
                <?php
                 if(isset($_SESSION['user']))
                { 
                    echo $_SESSION['user']; } 
                   
                   
                    ?>
                  
            </a></li>
                <li> <a href="./LogOut.php">Logout</a></li>
                
            </ul>
        </div>
    </div>