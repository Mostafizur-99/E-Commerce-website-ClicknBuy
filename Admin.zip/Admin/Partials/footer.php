<div class="footer">
        <div class="wrapper">
            <p class="text-center">all right reseved by <a href="">ClicknBuy</a></p>

        </div>
    </div>

<!------------footer end------------->
</body>
</html>