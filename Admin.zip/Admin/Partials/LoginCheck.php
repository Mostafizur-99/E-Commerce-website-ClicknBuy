<?php 

//check wheater the user log in or not
//Authiorization or acess control
if(!isset($_SESSION['user']))
{ 
//user is not log in
//Redirect to log in page
   $_SESSION['no-login-message']="<div class='error'>please log in to acess admin panel</div>"; 
   header('location:'.SITEURL.'Admin/login.php');
}

?>