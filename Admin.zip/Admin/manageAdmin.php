<?php include('Partials/menu.php') ?>

<div class="main-content">
    <div class="wrapper">
     <h1>Manage Admin</h1>
     <?php 
     if(isset($_SESSION['add'])){ 
        echo $_SESSION['add'];
        unset($_SESSION['add']);
     }
     if(isset($_SESSION['user_not_found'])){ 
        echo $_SESSION['user_not_found'];
        unset($_SESSION['user_not_found']);
     }
     if(isset($_SESSION['pwd_not_match'])){ 
        echo $_SESSION['pwd_not_match'];
        unset($_SESSION['pwd_not_match']);
     }
     if(isset($_SESSION['change_password'])){ 
        echo $_SESSION['change_password'];
        unset($_SESSION['change_password']);
     }
     if(isset($_SESSION['update_admin'])){ 
        echo $_SESSION['update_admin'];
        unset($_SESSION['update_admin']);
     }
    if(isset($_SESSION['delete'])){ 
        echo $_SESSION['delete'];
        unset($_SESSION['delete']);
    }
     ?>
     <div class="text-center">
     <a href="addadmin.php">Add Admin</a>
     </div>
     <div class="tbl-full" >
        <table>
            <tr>
            <th>serial number</th>
            <th>Full Name</th>
            <th>username</th>
            <th>Action</th>
            </tr>


            <?php 
        //querry get to all admin
        $sql="SELECT *FROM tbl_admin";
        $res=mysqli_query($conn,$sql);
        if($res==true){ 
            $count=mysqli_num_rows($res);
            $sn=1;
            if($count>0){ 
                while($rows=mysqli_fetch_assoc($res)){ 
                    $id=$rows['id'];
                    $full_name=$rows['full_name'];
                    $username=$rows['Username'];
                    ?>
                    <tr>
                    <td><?php echo $sn++ ?></td>
                    <td><?php echo $full_name ?> </td>
                    <td> <?php echo $username ?></td>
                   <td>
                     <a href="<?php echo SITEURL;?>Admin/updatePassword.php?id=<?php echo $id; ?>">Change Password &nbsp &nbsp</a>
                     <a href="<?php echo SITEURL;?>Admin/updateAdmin.php?id=<?php echo $id; ?>">update Admin &nbsp &nbsp</a>
                     <a href="<?php echo SITEURL;?>Admin/deleteAdmin.php?id=<?php echo $id; ?>">delete Admin </a>
                 </td>
                
                   
                </tr>
                <?php 
                }
            }
            else{ 
                //we do not have data in database
            }
        }


            ?>
        </table>
     </div>


    </div>
</div>


<?php include('Partials/footer.php') ?>