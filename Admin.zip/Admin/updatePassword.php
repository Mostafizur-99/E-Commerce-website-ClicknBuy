<?php include('Partials/menu.php'); ?>
<div class="main-content">
    <div class="wrapper">
        <h1>Change Password</h1>
        <?php 
        if(isset($_GET['id'])){ 
            $id=$_GET['id'];
        }
        ?>
        <div class="tbl-full">
            <form action="" method="POST">
                <table>
                    <tr>
                        <td>Current Password:</td>
                        <td><input type="password" name="current_password" placeholder=" current password"> </td>
                    </tr>
                    <tr>
                        <td> Neww password: </td>
                        <td><input type="password" name="new_password" placeholder=" new password"> </td>
                    </tr>
                    <tr>
                        <td> Confirm Password: </td>
                        <td> <input type="password" name="confirm_password" placeholder="Confirm password"></td>
                    </tr>
                    <tr>
                        <td colspan="2"> 
                            <input type="hidden" name="id" value="<?php echo $id ?>">
                            <input type="submit" name="submit" value="Change password">
                        </td>
                    </tr>
                </table>
            </form>
        </div>
    </div>
</div>
<?php  
   
   if(isset($_POST['submit'])){ 
    
    $id=$_POST['id'];
    $current_password=$_POST['current_password'];
    $new_password=$_POST['new_password'];
    $confirm_password=$_POST['confirm_password'];
   
   $sql="SELECT *FROM tbl_admin WHERE id=$id AND password='$current_password'";
   $res=mysqli_query($conn,$sql);
   if($res==true){ 

    $count=mysqli_num_rows($res);
    if($count==1){ 
      // echo "user found";
      //user exit and password canbe change
      //wheather the new password and confirm password are match or not
      if($new_password==$confirm_password){ 
      //update the password
      $sql2="UPDATE tbl_admin SET
      password='$new_password'
      WHERE id=$id


      ";
      $res2=mysqli_query($conn,$sql2);
      if($res==true){ 
        //DIsplay message
        $_SESSION['change_password']="<div class='sucess'>Password change successfully</div>";
        header('location:'.SITEURL.'Admin/manageAdmin.php');
      }
      else{ 
        //display error message
        $_SESSION['change_password']="<div class='error'>Fail to change password</div>";
        header('location:'.SITEURL.'Admin/manageAdmin.php');
      }
      
      }
      else{ 
        $_SESSION['pwd_not_match']="<div class='error'>Password not match</div>";
        header('location:'.SITEURL.'Admin/manageAdmin.php');
      }
     
    }
    else{ 
        $_SESSION['user_not_found']="<div class='error'>User not found</div>";
        header('location:'.SITEURL.'Admin/manageAdmin.php');
        
    }
   }
   }




?>
