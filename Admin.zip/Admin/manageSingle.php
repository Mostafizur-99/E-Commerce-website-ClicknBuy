<?php include('Partials/menu.php'); ?>
<div class="main-content">
    <div class="wrapper">
        <h1>
            Manage Single Product
        </h1>
        <?php 
           if(isset($_SESSION['upload-img'])){ 
            echo $_SESSION['upload-img'];
            unset($_SESSION['upload-img']);
           }
        if(isset( $_SESSION['add-single'])){ 
            echo  $_SESSION['add-single'];
            unset( $_SESSION['add-single']);
        }
        if(isset( $_SESSION['update_single'])){ 
            echo  $_SESSION['update_single'];
            unset( $_SESSION['update_single']);
        }
        ?>
       
        <div class="text-center">
     <a href="">Add Single Product</a>
        </div>
        <div class="tbl-full">
            <table>
                <tr>
                    <th>SN</th>
                    <th>Product picture</th>
                    <th>Title</th>
                    <th>Price</th>
                    <th>feature</th>
                    <th>Active</th>
                    <th>Action</th>
                   
                </tr>
                <?php 
                
                $sql="SELECT *FROM tbl_single";
                $res=mysqli_query($conn,$sql);
                if($res==true){ 
                    $count=mysqli_num_rows($res);
                    $sn=1;
                    if($count>0){ 
                        while($row=mysqli_fetch_assoc($res)){ 
                            $id=$row['id'];
                            $title=$row['title'];
                            $img_name=$row['image_name'];
                            $price=$row['price'];
                            $feature=$row['feature'];
                            $active=$row['active'];
                            ?>
                            <tr>
                                <td><?php echo $sn++; ?></td>
                                <td>
                                <?php 
                    //check wheater is available or not
                    if($img_name !=""){ 
                             ?>
                             <!---------img link----->
                             <img src="<?php echo SITEURL; ?>Images/Single/<?php echo $img_name; ?>" alt="" width="100px" height="70px">
                             <?php

                    }
                    else{ 
                        //display error message
                        echo "<div class='error'>Image Not Added. </div>";
                    }
               
                    

                    ?>

                                </td> 
                                <td><?php echo $title; ?></td>
                                <td><?php echo $price; ?></td>
                                <td><?php echo $feature; ?></td>
                                <td><?php echo $active; ?></td>
                                <td>
                                    <a href="<?php echo SITEURL; ?>Admin/updateSingle.php?id='<?php echo $id; ?>'">update Single product &nbsp &nbsp</a>
                                 <a href="<?php echo SITEURL; ?>Admin/deleteSingle.php?id=<?php echo $id; ?> &img_name=<?php echo $img_name; ?>">Delete Single product</a>
                                </td>
                               
                            </tr>
                            <?php 

                        }
                    }
                }
                
                ?>
            </table>
        </div>
        
    </div>
</div>

<?php include('Partials/footer.php'); ?>