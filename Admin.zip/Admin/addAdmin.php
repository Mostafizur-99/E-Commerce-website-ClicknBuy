<?php include('Partials/menu.php'); ?>
<div class="main-content">
    <div class="wrapper">
        <h1>Add Admin</h1>
 <div class="tbl-full tbl-add">
    <form action="" method="POST">
        <table>
            <tr>
                <td>Full name:</td>
                <td>
                <input type="text" name="full_name" placeholder="Enter your name">
                </td>
            </tr>
            <tr>
            <td>
                user name:
            </td>
            <td> 
<input type="text" name="username" placeholder="Enter username">
            </td>
            </tr>
            <tr>
                <td>Password:</td>
                <td><input type="password" name="password" placeholder="Enter password"> </td>
            </tr>
            <tr>
                <td colspan="2">
                    <input type="submit" name="submit" value="Add Admin">
                </td>
            </tr>
        </table>
    </form>
 </div>
    </div>
</div>
<?php include('Partials/footer.php'); ?>

<?php
  
  if(isset($_POST['submit'])){ 
    $full_name=$_POST['full_name'];
    $username=$_POST['username'];
    $password=$_POST['password'];

    $sql= "INSERT INTO tbl_admin SET 
    full_name='$full_name',
    username='$username',
    password='$password'  
    ";
  $res=mysqli_query($conn,$sql) or die(mysqli_error($conn));
  if($res==true){ 
       $_SESSION['add']="<div class='sucess'>Admin added sucessfully</div>"; 
       header('location:'.SITEURL.'Admin/manageAdmin.php');  
  }
  else{ 
   $_SESSION['add']="<div class='error'>failed to add Admin</div>";
   header('location:'.SITEURL.'Admin/manageAdmin.php');
  }
  }

?>