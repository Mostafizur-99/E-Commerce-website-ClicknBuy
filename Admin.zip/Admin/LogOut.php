<?php  
 include('../Config/Constants.php'); ?>

 <?php 
 session_destroy();
 header('location:'.SITEURL.'Admin/Login.php');
 
 /*$okay=1;
 $_SESSION['okay']=$okay;
 header('location:'.SITEURL.'Admin/index.php');
 */
 ?>