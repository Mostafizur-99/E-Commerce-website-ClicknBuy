<?php include('../Config/Constants.php');

$id=$_GET['id'];
$sql="DELETE FROM tbl_admin WHERE id=$id";
$res=mysqli_query($conn,$sql);
if($res==true){ 
    $_SESSION['delete']="<div class='sucess'> Admin delete successfully </div>";
    header('location:'.SITEURL.'admin/manageAdmin.php');
}
else{ 
    $_SESSION['delete']=" <div class='error'>Failed to delete Admin.Try again later </div>" ;
    header('location:'.SITEURL.'admin/manageAdmin.php');
}



?>
