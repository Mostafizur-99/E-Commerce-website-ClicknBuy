<?php include('Partials/menu.php');?>

<div class="main-content">
    <div class="wrapper">
        <h1>Manage Product</h1>
        <div class="text-center">
     <a href="addProduct.php">Add Product</a>
     </div>
        <?php 
        if(isset($_SESSION['add_product'])){ 
            echo $_SESSION['add_product'];
            unset($_SESSION['add_product']);
        } 
        if(isset($_SESSION['delete'])){ 
            echo $_SESSION['delete'];
            unset($_SESSION['delete']);
        } 
        if(isset($_SESSION['remove'])){ 
            echo $_SESSION['remove'];
            unset($_SESSION['remove']);
        }
        if(isset($_SESSION['delete'])){ 
           echo $_SESSION['delete'];
           unset($_SESSION['delete']); 
        }
        if(isset( $_SESSION['no-product-found'])){ 
            echo  $_SESSION['no-product-found'];
            unset( $_SESSION['no-product-found']);
        }
    if(isset($_SESSION['update'])){ 
        echo $_SESSION['update'];
        unset($_SESSION['update']);
    }
    if(isset($_SESSION['upload'])){ 
        echo $_SESSION['upload'];
        unset($_SESSION['upload']);
    }
        
        ?>
        <div class="tbl-full">
           
             <table>
                <tr>
                    <th>S.N</th>
                    <th>Title </th>
                    <th>Image</th>
                    <th>Feature</th>
                    
                    <th>Active</th>
                    <th>Action</th>
                </tr>
                <?php
               $sql="SELECT *FROM tbl_product";
                $res=mysqli_query($conn,$sql);
                
                $count=mysqli_num_rows($res);
                $sn=1;
                if($count>0){
                     //we have data in database
                     //getthe data 
                     while($row=mysqli_fetch_assoc($res)){ 
                        //get individual data
                        $id=$row['id'];
                        $title=$row['title'];
                        $img_name=$row['img_name'];
                        $feature=$row['feature'];
                        $active=$row['active'];
                       ?>
                          
                <tr>
                    <td><?php echo $sn++; ?></td>
                    <td><?php echo $title; ?></td>
                    <td> 
                    <?php 
                    //check wheater is available or not
                    if($img_name !=""){ 
                             ?>
                             <!---------img link----->
                             <img src="<?php echo SITEURL; ?>Images/Product/<?php echo $img_name; ?>" alt="" width="100px" height="70px">
                             <?php

                    }
                    else{ 
                        //display error message
                        echo "<div class='error'>Image Not Added. </div>";
                    }
               
                    

                    ?>
                    
                    </td>
                    <td><?php echo $feature; ?> </td>
                    <td> <?php echo $active; ?></td>
                    <td>
                        <a href="<?php echo SITEURL; ?>Admin/updateProduct.php?id=<?php echo $id; ?>">update Product &nbsp &nbsp</a>
                        <a href="<?php echo SITEURL;?>Admin/deleteProduct.php?id=<?php echo $id; ?> &img_name=<?php echo $img_name;?>">Delete product</a>
                    </td>
                </tr>
                           

                       <?php
                        
                     }

                }
                else{ 
                    //we don't have data in database
                    ?>
                   <tr>
                    <td colspan="6"> <div class="error">No Product added</div></td>
                   </tr>
                    <?php
                }
           

                ?>
               
              

             </table>

           
        </div>
    </div>
</div>


<?php include('Partials/footer.php'); ?>