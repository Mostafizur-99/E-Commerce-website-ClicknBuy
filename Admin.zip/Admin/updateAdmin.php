<?php include('Partials/menu.php'); ?>
<div class="main-content">
    <div class="wrapper">
        <h1>Update Admin</h1>
<?php  
//error_reporting(0); 
//undefine array key solved
if(isset($_GET['id'])){ 
$id=$_GET['id'];
$sql="SELECT *FROM tbl_admin WHERE id=$id";
$res=mysqli_query($conn,$sql);
if($res==true){ 

    $count=mysqli_num_rows($res);
if($count==1){ 
       
    $row=mysqli_fetch_assoc($res);
    $full_name=$row['full_name'];
    $username=$row['Username'];
}
else{ 
    header('location:'.SITEURL.'Admin/manageAdmin.php');
}


}
}
 

?>

        <div class="tbl-full">
            <form action="" method="POST">
            <table>
                <tr>
                    <td>full name:</td>
                    <td><input type="text" name="full_name" placeholder="<?php echo $full_name; ?>"> </td>
                    
                </tr>
                <tr>
                    <td>
                        username:
                    </td>
                    <td><input type="text" name="username" placeholder="<?php echo $username; ?>"> </td>
                </tr>
                <tr>
                <td colspan="2">
                    <input type="hidden" name="id" value="<?php echo $id; ?>">
                    <input type="submit" name="submit" value="update admin">
                </td>
                </tr>
            </table>
            </form>
        </div>
    </div>
</div>

<?php include('Partials/footer.php'); ?>
<?php
   
   if(isset($_POST['id'])){ 
    $id=$_POST['id'];
    $full_name=$_POST['full_name'];
    $username=$_POST['username'];

    $sql="UPDATE tbl_admin SET
    id='$id',
    full_name='$full_name',
    username='$username'
    WHERE id='$id'
    ";
   
   $res=mysqli_query($conn,$sql);
  
   if($res==true){ 
   
   $_SESSION['update_admin']="<div class='sucess'>Admin updated sucessfully</div>";
   header('location:'.SITEURL.'Admin/manageAdmin.php');
   }
   else{ 
     $_SESSION['update_admin']="<div class='error'>Failed to update Admin</div>";
    header('location:'.SITEURL.'Admin/manageAdmin.php');
   }
}

?>