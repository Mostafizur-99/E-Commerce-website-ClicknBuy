<?php include('../Config/constants.php'); ?>
<?php 
if(isset($_GET['id']) AND isset($_GET['img_name'])){ 

    $id=$_GET['id'];
    $img_name=$_GET['img_name'];
    if($img_name!=""){ 
        $path="../Images/Single/".$img_name;
        $remove=unlink($path);
        if($remove==false){ 
            $_SESSION['remove']="<div class='error'>Failed to remove img</div>";
            header('location:'.SITEURL.'Admin/manageSingle.php');
            die();
        }
       
    }
    $sql="DELETE FROM tbl_single WHERE id=$id ";
    $res=mysqli_query($conn,$sql);
    if($res==true){ 
        $_SESSION['delete_single']="<div class='sucess'> single Product Deleted sucessfully</div>";
        header('location:'.SITEURL.'Admin/manageSingle.php');
    }
    else{ 
        $_SESSION['delete_single']="<div class='error'> Failed to delete product</div>";
        header('location:'.SITEURL.'Admin/manageSingle.php');
    }
}
else{ 

}
  

?>