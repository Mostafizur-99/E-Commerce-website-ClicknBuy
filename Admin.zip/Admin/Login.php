<?php 
include('../Config/Constants.php');?>


<html>
<head>
    <title>Login</title>
    <link rel="stylesheet" href="../CSS/admin.css">

</head>
<body>
     
     <div class="main-content">
        <div class="wrapper">
            <h1>Login</h1>
            <?php 
            if(isset($_SESSION['login'])){
                echo $_SESSION['login'];
                unset($_SESSION['login']); 

            }
            if(isset($_SESSION['no-login-message'])){ 
                echo $_SESSION['no-login-message'];
                unset($_SESSION['no-login-message']);
            }
            ?>
            <div class="tbl-full">
                <form action="" method="POST">
                    <table>
                        <tr>
                            <td>Username:</td>
                            <td> <input type="text" name="username" placeholder="Enter username"></td>
                        </tr>
                        <tr>
                            <td> Password:</td>
                            <td> <input type="password" name="password" placeholder="Enter password"></td>
                        </tr>
                        <tr>
                            <td colspan="2">
                                <input type="submit" name="submit" value="Login">
                            </td>
                        </tr>
                    </table>
                </form>
            </div>
        </div>
     </div>

<?php include('Partials/footer.php'); ?>
<?php
if(isset($_POST['submit'])){ 
    $username=$_POST['username'];
    $password=$_POST['password'];
    $sql="SELECT *FROM tbl_admin WHERE Username='$username' AND password='$password'";
   $res=mysqli_query($conn,$sql);
   $count=mysqli_num_rows($res);
   if($count==1){ 
    
    $_SESSION['login']="<div class='sucess'>Login successfully</div>";
    
    header('location:'.SITEURL.'Admin/Index.php');
     $_SESSION['user']=$username;
     
     
   }
   else{ 
    $_SESSION['login']="<div class='error'>username or password did not match</div>";
    
    header('localhost'.SITEURL.'Admin/Login.php');

   }

}

?>

