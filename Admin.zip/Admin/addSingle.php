<?php include('Partials/menu.php'); ?>
<div class="main-content">
    <div class="wrapper">
        <h1>Add Single Product</h1>
        <?php 
        if(isset($_SESSION['upload-img'])){ 
            echo $_SESSION['upload-img'];
            unset($_SESSION['upload-img']);
        }
        ?>
        
        <div class="tbl-full">
            <form action="" method="POST" enctype="multipart/form-data">
                <table>
                    <tr>  
                 <td>Title:</td>
                 <td> <input type="text" name="title" placeholder=" product title" ></td>
                 </tr>
                 <tr>
                    <td>Image:</td>
                    <td> <input type="file" name="img"></td>
                 </tr>
                 <tr>
                    <td>Price:</td>
                    <td> <input type="number" name="price" placeholder="price"></td>
                 </tr>
                 <tr>
                    <td>Feature:</td>
                    <td> <input type="radio" name="feature" value="Yes">Yes
                       <input type="radio" name="feature" value="No"> No
                </td>
                 </tr>
                 <tr>
                    <td>Active:</td>
                    <td>
                        <input type="radio" name="active" value="Yes">Yes
                        <input type="radio" name="active" value="No">No
                    </td>
                 </tr>
                 <tr>
                    <td colspan="2"> <input type="submit" name="submit" value="Add Single product"></td>
                 </tr>
                </table>

            </form>
        </div>
        
    </div>
</div>
<?php include('Partials/footer.php'); ?>
<?php 

 if(isset($_POST['submit'])){ 

   $title=$_POST['title'];
   $price=$_POST['price'];
   if(isset($_POST['feature'])){ 
    $feature=$_POST['feature'];
   }
   else{ 
    $feature="NO";
   }
   if(isset($_POST['active'])){ 
    $active=$_POST['active'];
   }
   else{ 
    $active="No";
   }

   /*----------------img <se--></se--*/
   //print_r($_FILES['img']);
   //die();
   if(isset($_FILES['img']['name'])){ 
    $img_name=$_FILES['img']['name'];
    $ext=end(explode('.',$img_name));
    $img_name='product_'.rand(000,999).'.'.$ext;
    $source_path=$_FILES['img']['tmp_name'];
    $destination_path="../Images/Single/".$img_name;
    $upload=move_uploaded_file($source_path,$destination_path);
    if($upload==false){ 
        $_SESSION['upload-img']="<div class='error'>Failed to image uploaded</div>";
        header('location:'.SITEURL.'Admin/addSingle.php');
    }
   
   
   }
           

   $sql="INSERT INTO tbl_single SET 
   
   title='$title',
   image_name='$img_name',
   price='$price',
   feature='$feature',
   active='$active'

   ";
   $res=mysqli_query($conn,$sql);
   
   if($res==true){ 
    $_SEESION['add-single']="<div class='sucess'>Add single product sucessfully</div>";
    header('location:'.SITEURL.'Admin/manageSingle.php');
   }
   else{ 
    $_SESSION['add-single']="<div class='error'>Failed to add product</div>";
    header('location:'.SITEURL.'Admin/addSingle.php');
   }
 }


?>